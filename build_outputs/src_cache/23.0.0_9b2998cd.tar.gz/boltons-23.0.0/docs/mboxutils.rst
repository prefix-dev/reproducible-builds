``mboxutils`` - Unix mailbox utilities
======================================

.. automodule:: boltons.mboxutils
   :members:
   :undoc-members:
