``pathutils`` - Filesystem fun
==============================

.. automodule:: boltons.pathutils
   :members:
   :undoc-members:
