``tableutils`` - 2D data structure
==================================

.. automodule:: boltons.tableutils
   :members:
   :undoc-members:
