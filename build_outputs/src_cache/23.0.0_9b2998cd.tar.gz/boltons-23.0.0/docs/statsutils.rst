``statsutils`` - Statistics fundamentals
========================================

.. automodule:: boltons.statsutils
   :members:
   :undoc-members:
