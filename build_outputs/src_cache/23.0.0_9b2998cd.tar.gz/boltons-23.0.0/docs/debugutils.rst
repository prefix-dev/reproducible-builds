``debugutils`` - Debugging utilities
====================================

.. automodule:: boltons.debugutils
   :members:
   :undoc-members:
