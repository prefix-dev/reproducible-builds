``namedutils`` - Lightweight containers
=======================================

.. automodule:: boltons.namedutils
   :members:
   :undoc-members:
