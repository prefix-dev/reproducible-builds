``dictutils`` - Mapping types (OMD)
===================================

.. automodule:: boltons.dictutils
   :members:
   :undoc-members:
