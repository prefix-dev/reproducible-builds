``queueutils`` - Priority queues
================================

.. automodule:: boltons.queueutils
   :members:
   :undoc-members:
