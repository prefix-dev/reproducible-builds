``strutils`` - Text manipulation
=================================

.. automodule:: boltons.strutils
   :members:
   :undoc-members:
